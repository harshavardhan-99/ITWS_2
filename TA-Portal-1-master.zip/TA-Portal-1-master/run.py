from app import app
app.run(host='192.168.43.157' , debug=True)

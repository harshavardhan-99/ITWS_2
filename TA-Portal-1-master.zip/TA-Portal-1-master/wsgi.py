from app import app as application 

if __name__ == "__main__":
    application.run(host="https://192.168.43.157" , debug=True)
